# Can be multiple prefixes, like this: ("!", "?")
BOT_PREFIX = ("b!")
TOKEN = "ODExOTAyNTM2MDcxNjQzMTc2.YC49KQ.6EwWVfaf7wGqigZv7fncJZrcx-I"
APPLICATION_ID = "811902536071643176"
OWNERS = [604400576217743367]
BLACKLIST = []
 # Default cogs that I have created for the template
STARTUP_COGS = [
    "cogs.general", "cogs.help", "cogs.moderation", "cogs.owner",
]
