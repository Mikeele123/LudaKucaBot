# Updates List
Here is the list of all the updates that I made on this template.

### Version 2.1
* Made the help command dynamic
* Added a small description to all commands
* Added intents when creating the bot

### Version 2.0
* Added cogs
* Added f-strings and removed `.format()`
* Created [config file](config.py) for easier setup

### Version 1.2
* Added blacklist command
* Removed commands cooldown